<?php
$server = "localhost" ; 
$user ="root" ;
$test_pass = "ToKa111995";
$db_name = "show_db";
$con2 = mysqli_connect($server,$user,$test_pass,$db_name);

?>