<!DOCTYPE html>
<html>
<head>
    <title> Acessories Store </title>
    <link rel="stylesheet" href="css/style.css"/>
   </head>
<body class="body">
 <!-- start of main  div part -->
    <div class = " main-div" >
        <!--start of header div logo & nav --> 
      <div class = " header" >
         <div class = " logo"> <!--img of logo prefered to be  png -->
            <img src ="imges\icons\icons8-online-shop-96.png"  width= "50" height ="50" />
           <!--<img src= "Capture.png" width="50" height="50"/>-->
         </div>

         <div class="nav-link">
              <ul>
                         <li> <a href ="index.html" > Home</a></li>
                         <li> <a href ="product_detail.html" >product </a> </li>
                         <li> <a href ="login.html" >  login </a> </li>
                         <li> <a href ="sign_up.html" >  sign_up </a></li>
                         <li> <a href ="contact_us.html" >  contact_us </a></li>

              </ul>
             
         </div>
        
      </div>
     <!--end of header div logo & nav -->

    </div>
    <!-- div for space between others -->
    <div class = "Space10"  ></div>
    <!-- div for space between others -->

     <!--  start for main section head -->
    <div class = " main-section">  
           <div class = " item ">

            <img src ="imges\21_05_19_womens_watches_epsp_hero.jpg" alt = "item_img" width ="150" height = "150" /> 
            <h4>  item name </h4>
            <p> item price </p>
            <input type="submit" value ="More"/>
           </div>


        <!-- end  of main  section part --> 
    </div>

<!--  start of footer -->
<div class="footer"> 
  <div class = "end_logo">

    <img src ="imges\icons\icons8-online-shop-96.png"  width= "50" height ="50" />
       
  </div>

  <p> All right reserved to show inc 2019 </p>
    <div class = "social_div">
        <img src ="imges\icons\icons8-facebook-neu-48.png"  width= "50" height ="50" />
       <img src ="imges\icons\icons8-gmail-48.png"  width= "50" height ="50" />
       <img src ="imges\icons\icons8-twitter-48.png"  width= "50" height ="50" />
       
       <img src ="imges\icons\icons8-whatsapp-48.png"  width= "50" height ="50" />
       <img src ="imges\icons\icons8-yahoo-48.png"  width= "50" height ="50" />
    </div>

<!--  end of footer -->
</div>

  <!-- end  of main  div part -->
    </div >
   
</body>

</html>